import React from 'react';

class Discover extends React.Component {


  render () {
    return(
      <div>
        <h1
        style={{
          color: '#2d2d2d',
          marginTop: 80,
        }}>Découvrir des films</h1>
        <p>Découvrez ici un film au hasard</p>
      </div>
    );
  }
};

export default Discover;
