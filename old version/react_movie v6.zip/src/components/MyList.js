import React from 'react';

const MyList = () => {
  return(
    <div>
      <h1
        style={{
          marginTop: 80,
          color: '#2d2d2d',
        }}>
        MyList
      </h1>
    </div>
  );
};

export default MyList;
