import React from 'react';

const MyList = () => {
  return(
    <div>
      <p>MyList</p>
    </div>
  );
};

export default MyList;
