import React from 'react';

class Discover extends React.Component {


  render () {
    return(
      <div>
        <p>Discover</p>
      </div>
    );
  }
};

export default Discover;
