import React from 'react';

const MyList = () => {
  return(
    <div>
      <h1
        style={{
          color: 'grey',
        }}>
        MyList
      </h1>
    </div>
  );
};

export default MyList;
