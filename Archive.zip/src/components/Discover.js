import React from 'react';

class Discover extends React.Component {


  render () {
    return(
      <div>
        <h1
        style={{
          color: 'grey',
        }}>Découvrir des films</h1>
      </div>
    );
  }
};

export default Discover;
