import React from 'react';

import ReactDOM from 'react-dom';

class Popular extends React.Component {
  constructor() {
    super();
    this.state = {
      movies: [],
      newMovies: [],
      currentPage: 1,
      moviesPerPage: 2
    };
    this.handleClick = this.handleClick.bind(this);
  }

  componentDidMount = async () => {
    const API_KEY = "0e8950f53586e7cabd8650ab3a2440fe";
    const URL = `https://api.themoviedb.org/3/discover/movie?sort_by=popularity.desc&api_key=${API_KEY}`;

    fetch(URL)
      .then(res => res.json())
      .then(data => {
        console.log('data', data.results);

        this.setState({
          newMovies: data.results
        })
      });
    }

  handleClick(event) {
    this.setState({
      currentPage: Number(event.target.id)
    });
    console.log(this.state.newMovies);
    }

  render() {
    const { newMovies, currentPage, moviesPerPage } = this.state;

    // Logic for displaying movies
    const indexOfLastMovie = currentPage * moviesPerPage;
    const indexOfFirstMovie = indexOfLastMovie - moviesPerPage;
    const currentMovies = this.state.newMovies.slice(indexOfFirstMovie, indexOfLastMovie);

    const movieList = currentMovies.map((movie, index) => {
    let urlImg = `https://image.tmdb.org/t/p/w400${ movie.poster_path }`;
    return <li className="card col-12 col-md-6" key={index}><h5 className="card-title">{movie.title}</h5><img className="card-img-top mt-3" src={urlImg} alt={movie.title} /><p className="card-texte">{movie.overview}</p></li>;
  });

    // Logic for displaying page numbers
    const pageNumbers = [];
    for (let i = 1; i <= Math.ceil(newMovies.length / moviesPerPage); i++) {
      pageNumbers.push(i);
    }

    const renderPageNumbers = pageNumbers.map(number => {
      return (
        <li
          key={number}
          id={number}
          className="boutonNav"
          onClick={this.handleClick}
          style={{
            color: 'grey',
            border: '2px solid darkgrey',
            margin: '5px 5px',
            padding: '12px 20px',
            borderRadius: 10,
          }}
        >
          {number}
        </li>
      );
    });

    return (
      <div>

        <h1
        style={{
          color: 'grey',
        }}
        >Films populaires
        </h1>

        <ul
          style={{
            listStyle: 'none',
            display: 'flex',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
          }}>
          {renderPageNumbers}
        </ul>

        <ul
        className="row">
          {movieList}
        </ul>

      </div>
    );
  }
}

export default Popular;
